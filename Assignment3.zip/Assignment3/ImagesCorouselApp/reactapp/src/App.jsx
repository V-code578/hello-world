import React from 'react';
import ImageUploader from './ImageUploader';
import ImageCarousel from './ImageCarousel';

function App() {
    return (
        <div>
            <ImageUploader />
            <ImageCarousel />
        </div>
    );
}

export default App;