﻿using EmployeeDropdownLibrary.Models;
using EmployeeDropdownLibrary.Repos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace webapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeDetailsController : ControllerBase
    {
        private IEmployeeDetails EmpDetailsRepo;

        public EmployeeDetailsController(IEmployeeDetails repo)
        {
            EmpDetailsRepo = repo;
        }



        [HttpGet]

        public async Task<ActionResult> GetAll()
        {
            try
            {
                List<EmployeeDetails> emps = await EmpDetailsRepo.GetAll();
                return Ok(emps);
            }
            catch (Exception)
            {
                throw new Exception("Unable to get all Employees");

            }
        }


        [HttpGet("ById/{eid}")]


        public async Task<ActionResult> GetByEmpId(int eid)
        {
            try
            {
                List<EmployeeDetails> emps = await EmpDetailsRepo.GetByEmpId(eid);
                return Ok(emps);
            }
            catch (Exception)
            {
                throw new Exception("Unable to get Employees by Id");

            }
        }


        [HttpGet("BySingleId/{eid}")]

        public async Task<ActionResult> GetBySingleEmpId(int eid)
        {
            try
            {
                EmployeeDetails emp = await EmpDetailsRepo.GetBySingleEmpId(eid);
                return Ok(emp);
            }
            catch (Exception)
            {
                throw new Exception("There is no Employee");
            }

        }


        [HttpGet("ByDept/{dept}")]

        public async Task<ActionResult> GetByDept(string dept)
        {
            try
            {
                List<EmployeeDetails> emps = await EmpDetailsRepo.GetByDept(dept);
                return Ok(emps);
            }
            catch (Exception)
            {
                throw new Exception("Unable to get Employees by Department");

            }
        }


        [HttpGet("ByExp/{exp}")]

        public async Task<ActionResult> GetByExperience(float exp)
        {
            try
            {
                List<EmployeeDetails> emps = await EmpDetailsRepo.GetByExperience(exp);
                return Ok(emps);
            }
            catch (Exception)
            {
                throw new Exception("Unable to get Employees by Experience");

            }

        }

        [HttpGet("ByName/{name}")]

        public async Task<ActionResult> GetByName(string name)
        {
            try
            {
                List<EmployeeDetails> emps = await EmpDetailsRepo.GetByName(name);
                return Ok(emps);
            }
            catch (Exception)
            {
                throw new Exception("Unable to get Employees by Name");

            }

        }

        [HttpPost]

        public async Task<ActionResult> InsertEmp(EmployeeDetails employee)
        {
            try
            {
                await EmpDetailsRepo.InsertEmp(employee);
                return Created($"api/Employee/{employee.EmpId}", employee);
            }
            catch (Exception)
            {
                throw new Exception("Error while Inserting Employee");

            }
        }


        [HttpDelete]

        public async Task<ActionResult> DeleteEmp(int EmpId)
        {
            try
            {
                await EmpDetailsRepo.DeleteEmp(EmpId);
                return Ok();
            }
            catch (Exception)
            {
                throw new Exception("Unable to delete Employee");
            }
        }


        [HttpGet("Search/{term}")]
        public async Task<ActionResult> SearchEmployees(string term)
        {
            try
            {
                List<EmployeeDetails> emps = await EmpDetailsRepo.SearchEmployeesByName(term);
                return Ok(emps);
            }
            catch (Exception)
            {
                throw new Exception("Unable to search Employees");
            }
        }
    }
}
