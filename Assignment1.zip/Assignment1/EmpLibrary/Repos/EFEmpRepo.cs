﻿using EmpLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLibrary.Repos
{
    public class EFEmpRepo : IEmpRepo
    {
        EmpDBContext ctx = new EmpDBContext();
        public async Task DeleteEmployee(int eid)
        {
             Employee emp = await GetEmployee(eid);
             ctx.Employees.Remove(emp);
             await ctx.SaveChangesAsync();

        }

        public async Task<List<Employee>> GetAllEmployees()
        {
            List<Employee> employees = await ctx.Employees.ToListAsync();
            return employees;
        }

        public async Task<Employee> GetEmployee(int eid)
        {
            try
            {
                Employee emp = await (from e in ctx.Employees where e.EmpId == eid select e).FirstAsync();
                return emp;
            }
            catch(Exception)
            {
                throw new Exception("No such Employee");
            }
            
        }

        public async Task InsertEmployee(Employee emp)
        {
            ctx.Employees.Add(emp);
            await ctx.SaveChangesAsync();
        }

        public async Task UpdateEmployee(int eid, Employee emp)
        {
            Employee employee = await GetEmployee(eid);
            employee.EmpName = emp.EmpName;
            employee.Age = emp.Age;
            employee.Salary = emp.Salary;
            await ctx.SaveChangesAsync();
        }
    }
}
