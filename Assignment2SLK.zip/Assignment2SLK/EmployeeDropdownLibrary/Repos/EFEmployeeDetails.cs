﻿using EmployeeDropdownLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDropdownLibrary.Repos
{
    public class EFEmployeeDetails : IEmployeeDetails
    {
        EmployeeDetailsDBContext ctx = new EmployeeDetailsDBContext();
        public async Task DeleteEmp(int EmpId)
        {
            try
            {
                EmployeeDetails emp2del = await GetBySingleEmpId(EmpId);
                ctx.Employees.Remove(emp2del);
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw new Exception("Error while deleting the Employee or Invalid EmployeeId");
            }
        }

        public async Task<List<EmployeeDetails>> GetAll()
        {
            try
            {
                List<EmployeeDetails> emps = await ctx.Employees.ToListAsync();
                return emps;
            }
            catch (Exception)
            {
                throw new Exception("Unable tp get all Employees");

            }
        }

        public async Task<List<EmployeeDetails>> GetByDept(string dept)
        {
            try
            {
                List<EmployeeDetails> emp = await (from e in ctx.Employees where e.Department == dept select e).ToListAsync();
                return emp;
            }
            catch (Exception)
            {
                throw new Exception("There is no Employee in this Department");
            }
        }

        public async Task<List<EmployeeDetails>> GetByEmpId(int eid)
        {
            try
            {
                List<EmployeeDetails> emp = await (from e in ctx.Employees where e.EmpId == eid select e).ToListAsync();
                return emp;
            }
            catch (Exception)
            {
                throw new Exception("There is no Employee of this Id");
            }
        }


        public async Task<EmployeeDetails> GetBySingleEmpId(int eid)
        {
            try
            {
                EmployeeDetails emp = await (from e in ctx.Employees where e.EmpId == eid select e).FirstAsync();
                return emp;
            }
            catch (Exception)
            {
                throw new Exception("There is no Employee of this Id");
            }
        }

        public async Task<List<EmployeeDetails>> GetByExperience(float exp)
        {
            try
            {
                List<EmployeeDetails> emp = await (from e in ctx.Employees where e.Experience == exp select e).ToListAsync();
                return emp;
            }
            catch (Exception)
            {
                throw new Exception("There is no Employee of this Experience");
            }
        }

        public async Task<List<EmployeeDetails>> GetByName(string name)
        {
            try
            {
                List<EmployeeDetails> emp = await (from e in ctx.Employees where e.EmpName == name select e).ToListAsync();
                return emp;
            }
            catch (Exception)
            {
                throw new Exception("There is no Employee of this Name");
            }
        }

        public async Task InsertEmp(EmployeeDetails employee)
        {
            try
            {
                await ctx.Employees.AddAsync(employee);
                await ctx.SaveChangesAsync();
            }
            catch (Exception)
            {
                throw new Exception("Error while Inserting the Emloyee");
            }
        }

        public async Task<List<EmployeeDetails>> SearchEmployeesByName(string name)
        {
            return await ctx.Employees
                .Where(e => e.EmpName.Contains(name))
                .ToListAsync();
        }
    }
}
