﻿using ImageLibrary.Models;
using ImageLibrary.Repos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace webapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImageController : ControllerBase
    {
         private readonly IImageRepository _imageRepository;

    public ImageController(IImageRepository imageRepository)
    {
        _imageRepository = imageRepository;
    }

    [HttpGet]
    public async Task<IActionResult> GetImages()
    {
        var images = await _imageRepository.GetAllImages();
        return Ok(images);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetImage(int id)
    {
        var image = await _imageRepository.GetImageById(id);
        if (image == null)
        {
            return NotFound();
        }
        return Ok(image);
    }

        [HttpPost]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> AddImage([FromForm] IFormFile image)
        {
            if (image == null)
            {
                return BadRequest();
            }

            // Convert IFormFile to Image model if necessary
            var imageData = new Image
            {
                FileName = image.FileName,
                Data = await GetByteArrayFromFormFile(image)
            };

            await _imageRepository.AddImage(imageData);
            return Created($"api/Image/{imageData.Id}", imageData);
        }

        private async Task<byte[]> GetByteArrayFromFormFile(IFormFile file)
        {
            using (var memoryStream = new MemoryStream())
            {
                await file.CopyToAsync(memoryStream);
                return memoryStream.ToArray();
            }
        }

        [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteImage(int id)
    {
        await _imageRepository.DeleteImage(id);
        return Ok();
    }
    }
}
