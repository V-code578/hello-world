﻿using ImageLibrary.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageLibrary.Repos
{
    public class ImageRepository : IImageRepository
    {
        ImageDBContext ctx = new ImageDBContext();

        public async Task<IEnumerable<Image>> GetAllImages()
        {
            return await ctx.Images.ToListAsync();
        }

        public async Task<Image> GetImageById(int id)
        {
            return await ctx.Images.FindAsync(id);
        }

        public async Task AddImage(Image image)
        {
            ctx.Images.Add(image);
            await ctx.SaveChangesAsync();
        }

        public async Task DeleteImage(int id)
        {
            var image = await ctx.Images.FindAsync(id);
            if (image != null)
            {
                ctx.Images.Remove(image);
                await ctx.SaveChangesAsync();
            }
        }
    }
}
