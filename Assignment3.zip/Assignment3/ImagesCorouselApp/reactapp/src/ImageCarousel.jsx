import React, { useState, useEffect } from "react";
import axios from "axios";
import { Carousel } from "react-responsive-carousel";
import "react-responsive-carousel/lib/styles/carousel.min.css";

const ImageCarousel = () => {
    const [images, setImages] = useState([]);

    useEffect(() => {
        const fetchImages = async () => {
            try {
                const response = await axios.get("http://localhost:5094/api/Image");
                setImages(response.data);
            } catch (error) {
                console.error("Error fetching images:", error);
            }
        };

        fetchImages();
    }, []);

    return (
        <div>
            <h1>Image Carousel</h1>
            {images.length > 0 ? (
                <Carousel autoPlay={true} interval={4000} showThumbs={false}>
                    {images.map((image, index) => (
                        <div key={index}>
                            <img
                                src={`data:image/jpeg;base64,${image.data}`}
                                alt={image.fileName}
                            />
                        </div>
                    ))}
                </Carousel>
            ) : (
                <p>No images found.</p>
            )}
        </div>
    );
};

export default ImageCarousel;