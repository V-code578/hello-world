﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDropdownLibrary.Models
{
    public class EmployeeDetailsDBContext : DbContext
    {
        public EmployeeDetailsDBContext()
        {

        }
        public EmployeeDetailsDBContext(DbContextOptions<EmployeeDetailsDBContext> options) : base(options)
        {

        }

        public virtual DbSet<EmployeeDetails> Employees { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("data source=(localdb)\\MSSQLLocalDB; database=EmployeeDetailsDB; integrated security=true");
        }
    }
}
