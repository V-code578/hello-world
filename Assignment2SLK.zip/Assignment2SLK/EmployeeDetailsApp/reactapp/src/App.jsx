import React, { Component } from 'react';
import './App.css';
import Assignment from './Assignment';

function App() {
    return (
        <div>
            <Assignment />
        </div>
    )
}

export default App;
