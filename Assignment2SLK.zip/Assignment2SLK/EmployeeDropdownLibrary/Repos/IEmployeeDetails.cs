﻿using EmployeeDropdownLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDropdownLibrary.Repos
{
    public interface IEmployeeDetails
    {
        Task<List<EmployeeDetails>> GetAll();
        Task<List<EmployeeDetails>> GetByEmpId(int eid);

        Task<EmployeeDetails> GetBySingleEmpId(int eid);
        Task<List<EmployeeDetails>> GetByDept(string dept);

        Task<List<EmployeeDetails>> GetByExperience(float exp);

        Task<List<EmployeeDetails>> GetByName(string name);
        Task InsertEmp(EmployeeDetails employee);

        Task DeleteEmp(int EmpId);

        Task<List<EmployeeDetails>> SearchEmployeesByName(string name);
    }
}
