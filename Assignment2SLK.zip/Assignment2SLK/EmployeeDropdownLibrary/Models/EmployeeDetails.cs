﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDropdownLibrary.Models
{
    [Table("EmployeeDetails")]
    public class EmployeeDetails
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int EmpId { get; set; }

        [StringLength(30)]
        public string EmpName { get; set; }


        [StringLength(20)]
        public string Department { get; set; }

        public float Experience { get; set; }
    }
}
