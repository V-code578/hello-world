import React, { useState, useEffect } from 'react';

function Assignment() {
    const [employees, setEmployees] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [searchResults, setSearchResults] = useState([]);
    const [selectedDepartment, setSelectedDepartment] = useState('');
    const [selectedExperience, setSelectedExperience] = useState('');
    const [departmentOptions, setDepartmentOptions] = useState([]);
    const [experienceOptions, setExperienceOptions] = useState([]);

    useEffect(() => {
        fetch("http://localhost:5258/api/EmployeeDetails")
            .then(response => response.json())
            .then(data => {
                setEmployees(data);
                setSearchResults(data); // Set search results to all employees initially
                setDepartmentOptions(Array.from(new Set(data.map(employee => employee.department))));
            })
            .catch(error => console.error('Error fetching employees:', error));
    }, []);

    const handleSearch = (event) => {
        setSearchTerm(event.target.value);
        const term = event.target.value.trim().toLowerCase();
        const results = employees.filter(employee =>
            employee.empName.toLowerCase().includes(term)
        );
        setSearchResults(results);
    };

    const handleDepartmentChange = (event) => {
        setSelectedDepartment(event.target.value);
        const department = event.target.value;

        if (department !== '') {
            const filteredEmployees = employees.filter(employee => employee.department === department);
            setSearchResults(filteredEmployees);
            setExperienceOptions(Array.from(new Set(filteredEmployees.map(employee => employee.experience))));
        } else {
            // If no department is selected, show all employees
            setSearchResults(employees);
            setExperienceOptions([]);
        }
        setSelectedExperience(''); // Reset selected experience when department changes
    };

    const handleExperienceChange = (event) => {
        setSelectedExperience(event.target.value);
        const experience = parseFloat(event.target.value);

        if (!isNaN(experience)) {
            const filteredEmployees = employees.filter(employee =>
                employee.department === selectedDepartment && employee.experience === experience
            );
            setSearchResults(filteredEmployees);
        } else {
            // If no experience is selected, show employees based on the selected department
            const filteredEmployees = employees.filter(employee => employee.department === selectedDepartment);
            setSearchResults(filteredEmployees);
        }
    };

    return (
        <div>
            <h3>List of Employees</h3>
            <div>
                <label>Search:</label>
                <input type="text" value={searchTerm} onChange={handleSearch} />
            </div>
            <div>
                <label>Department:</label>
                <select value={selectedDepartment} onChange={handleDepartmentChange}>
                    <option value="">All</option>
                    {departmentOptions.map(department => (
                        <option key={department} value={department}>{department}</option>
                    ))}
                </select>
            </div>
            <div>
                <label>Experience:</label>
                <select value={selectedExperience} onChange={handleExperienceChange} disabled={!selectedDepartment}>
                    <option value="">All</option>
                    {experienceOptions.map(experience => (
                        <option key={experience} value={experience}>{experience}</option>
                    ))}
                </select>
            </div>
            {searchResults.length > 0 ? (
                <table border="1">
                    <thead>
                        <tr>
                            <th>EmpId</th>
                            <th>Name</th>
                            <th>Department</th>
                            <th>Experience</th>
                        </tr>
                    </thead>
                    <tbody>
                        {searchResults.map(employee => (
                            <tr key={employee.empId}>
                                <td>{employee.empId}</td>
                                <td>{employee.empName}</td>
                                <td>{employee.department}</td>
                                <td>{employee.experience}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <p>No employees found</p>
            )}
        </div>
    );
}

export default Assignment;