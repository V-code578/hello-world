﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using EmpLibrary.Models;
using EmpLibrary.Repos;

namespace webapi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        IEmpRepo empRepo;

        public EmployeeController(IEmpRepo repo)
        {
            empRepo = repo;
        }

        [HttpGet]
        public async Task<ActionResult> GetAll()
        {
            List<Employee> employees = await empRepo.GetAllEmployees();
            return Ok(employees);
        }

        [HttpGet("{eid}")]
        public async Task<ActionResult> GetOne(int eid)
        {
            try
            {
                Employee employee = await empRepo.GetEmployee(eid);
                return Ok(employee);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpPost]
        public async Task<ActionResult> Insert(Employee employee)
        {
            await empRepo.InsertEmployee(employee);
            return Created($"api/Employee/{employee.EmpId}", employee);
        }

        [HttpPut("{eid}")]
        public async Task<ActionResult> Update(int eid, Employee employee)
        {
            await empRepo.UpdateEmployee(eid, employee);
            return Ok(employee);
        }

        [HttpDelete("{eid}")]
        public async Task<ActionResult> Delete(int eid)
        {
            await empRepo.DeleteEmployee(eid);
            return Ok();

        }

    }
}
