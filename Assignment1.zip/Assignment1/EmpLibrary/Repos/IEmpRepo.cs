﻿using EmpLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmpLibrary.Repos
{
    public interface IEmpRepo
    {
        Task<List<Employee>> GetAllEmployees();
        Task<Employee> GetEmployee(int eid);
        Task InsertEmployee(Employee emp);
        Task UpdateEmployee(int eid, Employee emp);
        Task DeleteEmployee(int eid);
    }
}
